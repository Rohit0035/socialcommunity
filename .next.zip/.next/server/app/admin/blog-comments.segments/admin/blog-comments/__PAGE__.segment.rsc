1:"$Sreact.fragment"
2:I[65659,["/_next/static/chunks/7e196e5caef68549.js","/_next/static/chunks/a29092ddad23d4e6.js","/_next/static/chunks/711d9e4938c3daec.js","/_next/static/chunks/80dfff9c6daa94ab.js","/_next/static/chunks/ee6bfebd2f30023d.js","/_next/static/chunks/31af403c29b7581f.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"747wjKSo0IZ2DaVhOFgys","rsc":["$","$1","c",{"children":[["$","div",null,{"children":[["$","h2",null,{"className":"mb-4","children":"Blog Comments"}],["$","$L2",null,{}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/711d9e4938c3daec.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/80dfff9c6daa94ab.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/ee6bfebd2f30023d.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/31af403c29b7581f.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
