1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"ClientSegmentRoot"]
3:I[71284,["/_next/static/chunks/7e196e5caef68549.js","/_next/static/chunks/a29092ddad23d4e6.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"default"]
0:{"buildId":"747wjKSo0IZ2DaVhOFgys","rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/a29092ddad23d4e6.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
