var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/reset-password/[token]/route.js")
R.c("server/chunks/[root-of-the-server]__27a7f838._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_cf1ffc26._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_reset-password_[token]_route_actions_434cba31.js")
R.m(91350)
module.exports=R.m(91350).exports
