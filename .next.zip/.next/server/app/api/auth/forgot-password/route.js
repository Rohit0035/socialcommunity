var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/forgot-password/route.js")
R.c("server/chunks/[externals]__0824c676._.js")
R.c("server/chunks/_cf1ffc26._.js")
R.c("server/chunks/[root-of-the-server]__053ee461._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_forgot-password_route_actions_ada86dd3.js")
R.m(69226)
module.exports=R.m(69226).exports
