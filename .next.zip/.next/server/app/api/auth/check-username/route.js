var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/check-username/route.js")
R.c("server/chunks/[root-of-the-server]__d442603d._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_684ddacb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_check-username_route_actions_a753adb5.js")
R.m(18328)
module.exports=R.m(18328).exports
