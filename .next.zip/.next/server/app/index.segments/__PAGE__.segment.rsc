1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"747wjKSo0IZ2DaVhOFgys","rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/auth/register;307;"}
