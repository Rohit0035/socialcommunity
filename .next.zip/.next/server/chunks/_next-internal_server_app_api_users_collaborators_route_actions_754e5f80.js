module.exports=[22639,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_users_collaborators_route_actions_754e5f80.js.map