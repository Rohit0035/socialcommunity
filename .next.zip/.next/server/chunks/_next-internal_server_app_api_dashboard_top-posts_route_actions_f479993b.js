module.exports=[26257,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_top-posts_route_actions_f479993b.js.map