module.exports=[94095,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stories_feed_route_actions_bf3c0834.js.map