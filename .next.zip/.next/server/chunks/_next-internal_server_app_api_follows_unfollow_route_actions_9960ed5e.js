module.exports=[30137,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_follows_unfollow_route_actions_9960ed5e.js.map