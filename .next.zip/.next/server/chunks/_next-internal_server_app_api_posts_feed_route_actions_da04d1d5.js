module.exports=[72024,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_posts_feed_route_actions_da04d1d5.js.map