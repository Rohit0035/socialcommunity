module.exports=[81272,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_follows_reject_route_actions_beefe839.js.map