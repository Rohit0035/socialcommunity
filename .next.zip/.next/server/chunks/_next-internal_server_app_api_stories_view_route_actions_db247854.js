module.exports=[66503,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stories_view_route_actions_db247854.js.map