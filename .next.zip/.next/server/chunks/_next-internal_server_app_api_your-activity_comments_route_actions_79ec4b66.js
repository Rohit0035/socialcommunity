module.exports=[29306,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_your-activity_comments_route_actions_79ec4b66.js.map