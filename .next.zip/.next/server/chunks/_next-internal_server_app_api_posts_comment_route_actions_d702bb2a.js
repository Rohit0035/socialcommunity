module.exports=[73657,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_posts_comment_route_actions_d702bb2a.js.map