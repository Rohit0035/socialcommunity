module.exports=[96490,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_posts_toggle-like_route_actions_bb08140a.js.map