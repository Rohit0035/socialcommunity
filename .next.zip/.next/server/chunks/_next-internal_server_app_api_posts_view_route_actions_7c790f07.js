module.exports=[40462,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_posts_view_route_actions_7c790f07.js.map