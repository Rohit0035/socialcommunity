module.exports=[66908,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_your-activity_likes_route_actions_15e51f09.js.map