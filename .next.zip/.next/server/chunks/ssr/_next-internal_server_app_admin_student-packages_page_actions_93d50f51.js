module.exports=[34038,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_student-packages_page_actions_93d50f51.js.map