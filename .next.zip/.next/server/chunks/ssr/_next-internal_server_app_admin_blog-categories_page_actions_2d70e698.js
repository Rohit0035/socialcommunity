module.exports=[63695,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blog-categories_page_actions_2d70e698.js.map