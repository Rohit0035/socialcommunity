module.exports=[52860,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blog-comments_page_actions_affd4eb8.js.map