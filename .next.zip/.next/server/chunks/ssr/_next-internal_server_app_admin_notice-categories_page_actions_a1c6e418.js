module.exports=[93350,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_notice-categories_page_actions_a1c6e418.js.map