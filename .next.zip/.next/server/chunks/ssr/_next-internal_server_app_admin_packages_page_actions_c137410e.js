module.exports=[62297,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_packages_page_actions_c137410e.js.map