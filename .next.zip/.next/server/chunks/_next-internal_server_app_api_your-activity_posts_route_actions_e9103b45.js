module.exports=[20284,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_your-activity_posts_route_actions_e9103b45.js.map