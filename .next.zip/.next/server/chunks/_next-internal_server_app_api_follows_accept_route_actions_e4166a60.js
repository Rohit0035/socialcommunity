module.exports=[25309,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_follows_accept_route_actions_e4166a60.js.map