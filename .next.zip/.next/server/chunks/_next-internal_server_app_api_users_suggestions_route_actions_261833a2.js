module.exports=[12492,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_users_suggestions_route_actions_261833a2.js.map